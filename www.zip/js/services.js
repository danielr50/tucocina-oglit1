var app = angular.module('starter.services', []);

